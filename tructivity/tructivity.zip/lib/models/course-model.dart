class CourseModel {
  final String teacher, room, subject;
  CourseModel(
      {required this.room, required this.subject, required this.teacher});
}
